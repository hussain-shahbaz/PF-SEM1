#include<iostream>
using namespace std;
main()
{
cout<<"----------------------------------"<<endl;
cout<<" 0       ^__^                     "<<endl;
cout<<"   0     (00)\____________        "<<endl;
cout<<"         (__)\            )/\/    "<<endl;
cout<<"             ||--------w  |       "<<endl;
cout<<"             ||          || "<<endl;

}