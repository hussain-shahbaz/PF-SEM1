#include<iostream>
using namespace std;
main()
{
system("color 15");
cout<<"PACMAN"<<endl;
cout<<"      .::----------::.           "<<endl;
cout<<"    .------------------.         "<<endl;
cout<<"   .--------------------.        "<<endl;
cout<<"  -----------------------:.      "<<endl;
cout<<" :-------------------::.         "<<endl;
cout<<" -----------------:.             "<<endl;
cout<<" :--------------------:..        "<<endl;
cout<<"  -----------------------:.      "<<endl;
cout<<"  .----------------------:        "<<endl;
cout<<"   .--------------------:        "<<endl;
cout<<"     .:---------------:.         "<<endl;


}