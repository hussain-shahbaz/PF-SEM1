#include<iostream>
using namespace std;
int main(){
cout<<"     8       "<<endl;
cout<<"   8   8     "<<endl;
cout<<"  8888888    "<<endl;
cout<<"  8     8    "<<endl;
cout<<"  8     8    "<<endl;
cout<<endl;
cout<<"  88      88     "<<endl;
cout<<"  88    88 "<<endl;
cout<<"  88   88   "<<endl;
cout<<"  8888"<<endl;
cout<<"  88   88"<<endl;
cout<<"  88    88 "<<endl;
cout<<"  88      88     "<<endl;
cout<<endl;
cout<<"  88888888"<<endl;
cout<<"       88"<<endl;
cout<<"     88"<<endl;
cout<<"   88"<<endl;
cout<<" 88"<<endl;
cout<<"88888888"<<endl;
cout<<endl;
cout<<"     8888"<<endl;
cout<<"   88    88 "<<endl;
cout<<"   88"<<endl;
cout<<"     8888"<<endl;
cout<<"         88"<<endl;
cout<<"   88    88 "<<endl;
cout<<"     8888"<<endl;
}