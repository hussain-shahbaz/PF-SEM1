

    while(true){
        int input;