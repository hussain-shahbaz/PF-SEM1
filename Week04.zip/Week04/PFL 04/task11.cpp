#include<iostream>
using namespace std;
main(){
    cout<<"Enter your name";
    string name;
    cin>>name;
    while(true){
        cout<<name<<endl;
    }
}