#include<iostream>
using namespace std;
void calculatefuel(int n);
main(){
	int distance;
	cin>>distance;
	calculatefuel(n);
}
void calculatefuel(int distance){
	int fuel = 10*distance;
	cout<<d;
}
